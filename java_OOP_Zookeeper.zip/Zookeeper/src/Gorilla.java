
public class Gorilla extends Mammal {
	//	do I need a constructor?
	public Gorilla() {
		super();
	}
//	Methods
	public void throwSomething() {
		if(this.energy < 5) {
			System.out.println("Too tired to throw anything.");
			this.displayEnergy();
		}
		else {
			this.energy -= 5;
			System.out.println("The gorilla has thrown itself");
			this.displayEnergy();
		}
	}
	public void eatBananas() {
		int counter = 0;
		while(this.energy < 100) {
			if(counter < 10) {
				this.energy ++;
				counter ++;
			}
			else {
				break;
			}
		}
		System.out.println("Mmm, banana.");
		this.displayEnergy();
	}
	public void climb() {
		if(this.energy < 10) {
			System.out.println("Too tired to climb.");
			this.displayEnergy();
		}
		else {
			this.energy -= 10;
			System.out.println("TIme to climb!");
			this.displayEnergy();
		}
	}
}
