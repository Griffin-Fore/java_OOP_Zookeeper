
public class Mammal {
	protected int energy = 100;
	
	public Mammal() {
	}
	
	public Mammal(int energy) {
		this.energy = energy;
	}
	
	protected int displayEnergy() {
		System.out.println("Energy level: " + energy);
		return energy;
	}
	
	public void setEnergy(int e) {
		this.energy = e;
	}
}
