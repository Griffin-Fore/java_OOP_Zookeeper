
public class Bat extends Mammal {
//	how to super the energy
	public Bat() {
		super(300);
	}
	
	public void fly() {
		if(energy < 50) {
			System.out.println("Too tired to fly.");
			this.displayEnergy();
		}
		else {
			this.energy -= 50;
			System.out.println("The bat has taken flight!");
			this.displayEnergy();
		}
	}
	
	public void eatHumans() {
		int counter = 0;
		while(this.energy < 300) {
			if(counter < 25) {
				this.energy ++;
				counter ++;
			}
			else {
				break;
			}
		}
		System.out.println("The humans are tasty!");
		this.displayEnergy();
	}
	
	public void attackTown() {
		if(this.energy < 100) {
			System.out.println("Too tired to attack");
			this.displayEnergy();
		}
		else {
			this.energy -= 100;
			System.out.println("This justin, a giant bat has attacked the town!");
			this.displayEnergy();
		}
	}
}