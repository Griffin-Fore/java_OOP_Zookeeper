
public class AnimalTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//		create an instance of the gorilla class,
//		have the gorilla throw things 3 times,
//		eat bananas twice,
//		climb once,
//		and print the gorilla's energy level.
		Gorilla grod = new Gorilla();
		grod.displayEnergy();
		grod.throwSomething();
		grod.throwSomething();
		grod.throwSomething();
		grod.eatBananas();
		grod.eatBananas();
		grod.eatBananas();
		grod.climb();
		grod.setEnergy(4);
		grod.throwSomething();
		grod.setEnergy(9);
		grod.climb();
		
		Bat manbat = new Bat();
		manbat.setEnergy(49);
		manbat.fly();
		manbat.setEnergy(295);
		manbat.eatHumans();
		manbat.setEnergy(99);
		manbat.attackTown();
//		attacking three towns, 
//		eating two humans, 
//		flying twice, 
//		and then displaying its energy. 
//		Use the display energy from the superclass!
		manbat.setEnergy(300);
		manbat.attackTown();
		manbat.attackTown();
		manbat.attackTown();
		manbat.eatHumans();
		manbat.eatHumans();
		manbat.fly();
		manbat.fly();
		manbat.displayEnergy();
	}

}